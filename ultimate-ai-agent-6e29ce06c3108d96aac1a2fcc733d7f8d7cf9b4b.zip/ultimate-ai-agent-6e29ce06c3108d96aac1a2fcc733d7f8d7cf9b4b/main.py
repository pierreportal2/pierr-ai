"""Entry point for the reasoning agent."""
from reasoning_agent.__main__ import main

if __name__ == "__main__":
    main()
